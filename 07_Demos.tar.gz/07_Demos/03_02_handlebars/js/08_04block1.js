  //Code here
  var data = { people: [
    {name: "Eli"},
    {name: "Julian"},
    {name: "Paul"},
    {name: "Manton"},
    {name: "Antonio"},
    {name: "Gabriel"},
    {name: "Danny"},
    {name: "Kareem"},
    {name: "Jordan"},
  ], group: "PWA2" };
 //Code here
